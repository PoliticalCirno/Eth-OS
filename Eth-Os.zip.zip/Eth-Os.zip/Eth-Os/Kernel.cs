﻿using System;
using System.Collections.Generic;
using System.Text;
using Sys = Cosmos.System;

namespace Eth_Os
{
    public class Kernel : Sys.Kernel
    {
        protected override void BeforeRun()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Blue;

            Console.WriteLine("Licensed under Gnu public license v3.0");
            Console.WriteLine("Copyright(c) Sam Lee. All rights reserve.");
            Console.WriteLine("Debug build 92720");
            
            Console.ResetColor();
        }

        protected override void Run()
        {
            Console.BackgroundColor = ConsoleColor.Red;

            Console.Write("Eth-Build-92720>");
            Console.ResetColor();
            string input = "";

            input = Console.ReadLine();

            HandleThisCommand(input);



        }
        private void HandleThisCommand(string input)
        {

            if (input == "Hello")
            {

                Console.WriteLine("hello there");

            }
            else
            if (input == "Help")
            {
                Console.WriteLine("Rb - SysLinux Reboot");
                Console.WriteLine("Sd - ACPI Shutdown");
            }
            else if(input == "Rb")
            {
                Cosmos.System.Power.Reboot();
            }
            else if(input == "Sd")
            {
                Cosmos.System.Power.Shutdown();
            }
            else
            {
                Console.WriteLine("Invalid Argument");
            }
            

        }

        }
    }
